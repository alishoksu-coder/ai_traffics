import os

html_content = """<!DOCTYPE html>
<html lang="kk">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AI Traffic Monitoring & Forecasting - Қорғау презентациясы</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=JetBrains+Mono:wght@400;700&family=Outfit:wght@400;600;800;900&display=swap" rel="stylesheet">
    <style>
        :root {
            --bg-color: #f8fafc;
            --surface-color: rgba(255, 255, 255, 0.7);
            --card-border: rgba(148, 163, 184, 0.4);
            --text-main: #0f172a;
            --text-muted: #334155;
            --accent-cyan: #0284c7;
            --accent-blue: #2563eb;
            --accent-purple: #7c3aed;
            --glow-cyan: rgba(2, 132, 199, 0.15);
            --glow-blue: rgba(37, 99, 235, 0.15);
            --glow-purple: rgba(124, 58, 237, 0.15);
        }

        * { box-sizing: border-box; margin: 0; padding: 0; }

        body {
            font-family: 'Inter', sans-serif;
            background-color: var(--bg-color);
            color: var(--text-main);
            overflow: hidden;
            line-height: 1.6;
        }

        .bg-layer {
            position: fixed; top: 0; left: 0; width: 100vw; height: 100vh;
            z-index: -1;
            background-image: 
                linear-gradient(rgba(0, 0, 0, 0.04) 1px, transparent 1px),
                linear-gradient(90deg, rgba(0, 0, 0, 0.04) 1px, transparent 1px);
            background-size: 40px 40px;
            background-position: center center;
        }
        
        .bg-layer::before {
            content: ''; position: absolute;
            top: -10%; left: -10%; width: 50%; height: 50%;
            background: radial-gradient(circle, var(--glow-blue), transparent 60%);
            filter: blur(100px);
        }

        .bg-layer::after {
            content: ''; position: absolute;
            bottom: -10%; right: -10%; width: 50%; height: 50%;
            background: radial-gradient(circle, var(--glow-purple), transparent 60%);
            filter: blur(100px);
        }

        nav {
            position: fixed; top: 0; left: 0; width: 100%; height: 60px;
            background: rgba(255, 255, 255, 0.85);
            backdrop-filter: blur(12px);
            border-bottom: 1px solid var(--card-border);
            display: flex; align-items: center; padding: 0 40px;
            z-index: 100; justify-content: space-between;
        }

        .nav-brand {
            font-family: 'Outfit', sans-serif; font-weight: 800; font-size: 1.2rem;
            background: linear-gradient(90deg, var(--accent-cyan), var(--accent-purple));
            -webkit-background-clip: text; -webkit-text-fill-color: transparent;
        }

        .nav-dots { display: flex; gap: 8px; }

        .nav-dot {
            width: 10px; height: 10px; border-radius: 50%;
            background: #cbd5e1; cursor: pointer; transition: all 0.3s;
        }

        .nav-dot.active {
            background: var(--accent-cyan);
            box-shadow: 0 0 10px var(--accent-cyan);
            transform: scale(1.3);
        }

        .slide-counter {
            font-family: 'JetBrains Mono', monospace; font-size: 0.9rem;
            color: var(--text-muted); font-weight: bold;
        }

        .slides-container {
            height: 100vh; width: 100vw;
            transition: transform 0.6s cubic-bezier(0.22, 1, 0.36, 1);
        }

        section {
            height: 100vh; width: 100vw;
            padding: 100px 60px 40px 60px;
            display: flex; flex-direction: column; justify-content: center; align-items: center;
        }

        .content-wrapper {
            width: 100%; max-width: 1200px; max-height: 100%;
            display: flex; flex-direction: column; justify-content: center;
        }

        h1, h2, h3 { font-family: 'Outfit', sans-serif; margin-bottom: 20px; font-weight: 800; }
        h1 { font-size: 4rem; line-height: 1.1; margin-bottom: 30px; letter-spacing: -0.02em; }
        h2 {
            font-size: 2.8rem; color: var(--text-main);
            border-left: 6px solid var(--accent-cyan);
            padding-left: 20px; margin-bottom: 40px;
        }

        .text-gradient {
            background: linear-gradient(90deg, var(--accent-cyan), var(--accent-blue));
            -webkit-background-clip: text; -webkit-text-fill-color: transparent;
        }

        p, li { font-size: 1.2rem; color: var(--text-muted); margin-bottom: 15px; }

        .glass-card {
            background: var(--surface-color);
            backdrop-filter: blur(16px); -webkit-backdrop-filter: blur(16px);
            border: 1px solid var(--card-border);
            border-radius: 24px; padding: 30px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.05);
            transition: transform 0.3s, box-shadow 0.3s;
        }
        
        .glass-card:hover {
            transform: translateY(-5px); border-color: rgba(2, 132, 199, 0.4);
            box-shadow: 0 15px 40px rgba(2, 132, 199, 0.1);
        }

        .grid-2 { display: grid; grid-template-columns: 1fr 1fr; gap: 30px; }
        .grid-3 { display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; }
        .grid-4 { display: grid; grid-template-columns: repeat(4, 1fr); gap: 20px; }

        .badge {
            display: inline-block; padding: 6px 14px; border-radius: 20px;
            font-size: 0.9rem; font-weight: 600;
            background: rgba(37, 99, 235, 0.1); color: var(--accent-blue);
            border: 1px solid rgba(37, 99, 235, 0.3);
            margin-right: 10px; margin-bottom: 10px;
        }

        ul.custom-list { list-style: none; }
        ul.custom-list li { position: relative; padding-left: 35px; color: var(--text-main); }
        ul.custom-list li::before {
            content: '\\f101'; font-family: 'Font Awesome 6 Free'; font-weight: 900;
            position: absolute; left: 0; top: 2px; color: var(--accent-cyan);
        }

        .academic-table {
            width: 100%; border-collapse: collapse;
            background: var(--surface-color); border-radius: 16px; overflow: hidden;
            border: 1px solid var(--card-border);
        }
        .academic-table th {
            background: rgba(241, 245, 249, 0.9); color: var(--text-main);
            padding: 15px; text-align: left; font-family: 'JetBrains Mono', monospace;
            border-bottom: 1px solid var(--card-border);
        }
        .academic-table td {
            padding: 15px; border-bottom: 1px solid rgba(203, 213, 225, 0.5);
            color: var(--text-main);
        }
        .academic-table tr:last-child td { border-bottom: none; }
        .academic-table tr:hover td { background: rgba(0,0,0,0.02); }
        .highlight-cell { color: var(--accent-cyan) !important; font-weight: bold; }

        .flow-diagram {
            display: flex; align-items: center; justify-content: center;
            flex-wrap: wrap; gap: 15px; margin: 30px 0;
        }
        .flow-node {
            background: #ffffff; border: 1px solid var(--accent-blue);
            padding: 15px 25px; border-radius: 12px; font-weight: 600;
            box-shadow: 0 4px 15px var(--glow-blue); text-align: center; color: var(--text-main);
        }
        .flow-arrow { color: var(--accent-cyan); font-size: 1.5rem; }
        
        .lstm-diagram { display: flex; flex-direction: column; align-items: center; gap: 20px; }
        .lstm-block {
            width: 300px; text-align: center; padding: 15px;
            background: rgba(124, 58, 237, 0.05); border: 1px solid var(--accent-purple);
            border-radius: 12px; color: var(--text-main);
        }

        .fade-up { opacity: 0; transform: translateY(40px); transition: opacity 0.8s ease, transform 0.8s ease; }
        .fade-up.visible { opacity: 1; transform: translateY(0); }
        .delay-1 { transition-delay: 0.1s; }
        .delay-2 { transition-delay: 0.2s; }
        .delay-3 { transition-delay: 0.3s; }

        .dashboard-mockup {
            border: 2px solid var(--card-border); border-radius: 12px;
            background: #ffffff; overflow: hidden;
            box-shadow: 0 20px 50px rgba(0,0,0,0.1);
        }
        .mockup-header {
            height: 30px; background: #f1f5f9; display: flex; align-items: center; padding: 0 15px; gap: 6px;
            border-bottom: 1px solid var(--card-border);
        }
        .mockup-dot { width: 10px; height: 10px; border-radius: 50%; background: #ef4444; }
        .mockup-dot:nth-child(2) { background: #eab308; }
        .mockup-dot:nth-child(3) { background: #22c55e; }
    </style>
</head>
<body>
    <div class="bg-layer"></div>
    
    <nav>
        <div class="nav-brand">AI Traffic Defense</div>
        <div class="nav-dots" id="nav-dots"></div>
        <div class="slide-counter" id="slide-counter">1 / 19</div>
    </nav>

    <main class="slides-container" id="slides-container">
        
        <!-- 1. Титульный слайд -->
        <section>
            <div class="content-wrapper fade-up">
                <div style="margin-bottom: 20px;">
                    <span class="badge">PhD Dissertation Defense / IEEE Level</span>
                    <span class="badge">AI Traffic Monitoring & Forecasting</span>
                </div>
                <h1>Қалалық ортада көлік ағындарын <br><span class="text-gradient">мониторингтеу және болжау</span> <br>үшін AI-қосымшасын әзірлеу</h1>
                
                <div style="display: flex; justify-content: flex-end; width: 100%; margin-bottom: 30px; margin-top: 10px;">
                    <div style="text-align: left; background: rgba(255, 255, 255, 0.6); padding: 15px 25px; border-left: 4px solid var(--accent-cyan); border-radius: 8px; box-shadow: 0 4px 15px rgba(0,0,0,0.05);">
                        <p style="margin: 0; font-size: 1.1rem; color: var(--text-main);"><strong>Орындаған:</strong> Сулейменов Алишер ЕТБҚ-45</p>
                        <p style="margin: 8px 0 0 0; font-size: 1.1rem; color: var(--text-main);"><strong>Ғылыми жетекші:</strong> Кусаинова Айнұр Төлеубекқызы,</p>
                        <p style="margin: 0; font-size: 1.0rem; color: var(--text-muted);">кафедраның аға оқытушысы, PhD.</p>
                    </div>
                </div>

                <div style="text-align: center; margin-bottom: 20px;">
                    <p style="font-size: 1.2rem; color: var(--text-main); font-weight: 600;">Астана, 2026</p>
                </div>
                
                <div class="glass-card" style="display: inline-block; padding: 20px 30px;">
                    <h3 style="font-size: 1.1rem; color: var(--text-muted); margin-bottom: 10px;">Негізгі технологиялар стегі:</h3>
                    <div>
                        <span class="badge" style="border-color: #3b82f6;">Python</span>
                        <span class="badge" style="border-color: #10b981;">Django</span>
                        <span class="badge" style="border-color: #3b82f6;">PostgreSQL</span>
                        <span class="badge" style="border-color: #ef4444;">PyTorch (LSTM)</span>
                        <span class="badge" style="border-color: #f59e0b;">Random Forest</span>
                        <span class="badge" style="border-color: #8b5cf6;">REST API</span>
                    </div>
                </div>
            </div>
        </section>

        <!-- 2. Актуальность проблемы -->
        <section>
            <div class="content-wrapper">
                <h2 class="fade-up">Мәселенің өзектілігі</h2>
                <div class="grid-2">
                    <div class="glass-card fade-up delay-1">
                        <h3><i class="fa-solid fa-city text-gradient"></i> Мегаполистердің сын-қатерлері</h3>
                        <ul class="custom-list">
                            <li>Қалалық трафиктің экспоненциалды өсуі.</li>
                            <li>Жол желісінің созылмалы шамадан тыс жүктелуі.</li>
                            <li>Экологиялық және экономикалық шығындар.</li>
                        </ul>
                    </div>
                    <div class="glass-card fade-up delay-2">
                        <h3><i class="fa-solid fa-chart-line text-gradient"></i> Ағымдағы әдістердің шектеулері</h3>
                        <ul class="custom-list">
                            <li>Қолмен талдау және статикалық модельдердің шектеулігі.</li>
                            <li>Проактивті интеллектуалды мониторинг қажеттілігі.</li>
                            <li><strong>Data-driven urban mobility</strong> (деректерге негізделген қалалық ұтқырлық) жүйесіне көшу қажеттілігі.</li>
                        </ul>
                    </div>
                </div>
            </div>
        </section>

        <!-- 3. Цель и задачи проекта -->
        <section>
            <div class="content-wrapper">
                <h2 class="fade-up">Жобаның мақсаты мен міндеттері</h2>
                <div class="glass-card fade-up delay-1" style="margin-bottom: 30px; border-left: 4px solid var(--accent-cyan);">
                    <h3 style="color: var(--text-main);">Зерттеу мақсаты</h3>
                    <p>Қалалық жағдайда көлік ағындарын жинау, мониторингтеу, талдау және болжау үшін кешенді AI-қосымшасын әзірлеу.</p>
                </div>
                <div class="grid-3">
                    <div class="glass-card fade-up delay-2" style="text-align: center;"><i class="fa-solid fa-database text-gradient fa-2x mb-3" style="margin-bottom:15px;"></i><br>Жол қозғалысы туралы деректерді жинау және сақтау.</div>
                    <div class="glass-card fade-up delay-2" style="text-align: center;"><i class="fa-solid fa-server text-gradient fa-2x mb-3" style="margin-bottom:15px;"></i><br>Ақауларға төзімді backend жүйесін құру.</div>
                    <div class="glass-card fade-up delay-2" style="text-align: center;"><i class="fa-solid fa-brain text-gradient fa-2x mb-3" style="margin-bottom:15px;"></i><br>Жүктемені болжауға арналған ML-модулін әзірлеу.</div>
                    <div class="glass-card fade-up delay-3" style="text-align: center;"><i class="fa-solid fa-map-location-dot text-gradient fa-2x mb-3" style="margin-bottom:15px;"></i><br>Интерактивті картада көрсеткіштерді визуализациялау.</div>
                    <div class="glass-card fade-up delay-3" style="text-align: center;"><i class="fa-solid fa-scale-balanced text-gradient fa-2x mb-3" style="margin-bottom:15px;"></i><br>Baseline және нейрожелілік ML-модельдерін салыстыру.</div>
                    <div class="glass-card fade-up delay-3" style="text-align: center;"><i class="fa-solid fa-cubes text-gradient fa-2x mb-3" style="margin-bottom:15px;"></i><br>Масштабтау үшін архитектураны дайындау (IoT).</div>
                </div>
            </div>
        </section>

        <!-- 4. Объект и предмет исследования -->
        <section>
            <div class="content-wrapper">
                <h2 class="fade-up">Зерттеу нысаны мен пәні</h2>
                <div class="grid-2" style="margin-top: 50px;">
                    <div class="glass-card fade-up delay-1" style="text-align: center; padding: 60px 40px;">
                        <i class="fa-solid fa-road fa-4x mb-4" style="color: var(--accent-blue); margin-bottom: 20px;"></i>
                        <h3>Зерттеу нысаны</h3>
                        <p style="font-size: 1.4rem; color: var(--text-main);">Қалалық ортадағы көлік ағындары</p>
                    </div>
                    <div class="glass-card fade-up delay-2" style="text-align: center; padding: 60px 40px;">
                        <i class="fa-solid fa-network-wired fa-4x mb-4" style="color: var(--accent-purple); margin-bottom: 20px;"></i>
                        <h3>Зерттеу пәні</h3>
                        <p style="font-size: 1.4rem; color: var(--text-main);">Жолдардың жүктелуін талдау және болжау үшін машиналық оқыту әдістері</p>
                    </div>
                </div>
            </div>
        </section>

        <!-- 5. GAP-анализ -->
        <section>
            <div class="content-wrapper">
                <h2 class="fade-up">Мониторинг жүйелерінің GAP-талдауы</h2>
                <div class="fade-up delay-1">
                    <table class="academic-table">
                        <thead>
                            <tr>
                                <th>Дәстүрлі жүйелер</th>
                                <th>Шектеулер (GAP)</th>
                                <th>Ұсынылатын AI-шешім</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>Бағдаршамдардың статикалық ережелері</td>
                                <td>Кенеттен болатын кептелістерге бейімділіктің төмендігі</td>
                                <td class="highlight-cell">Data Pipeline арқылы динамикалық мониторинг</td>
                            </tr>
                            <tr>
                                <td>Реактивті карталар (пост-фактум)</td>
                                <td>Қысқа мерзімді болжамның болмауы (30-60 мин)</td>
                                <td class="highlight-cell">ML-болжау (LSTM / Moving Average)</td>
                            </tr>
                            <tr>
                                <td>Аналитиктердің қолмен талдауы</td>
                                <td>Ұзақ, қымбат, адами факторға тәуелді</td>
                                <td class="highlight-cell">Автоматтандырылған Dashboard және API</td>
                            </tr>
                            <tr>
                                <td>Шашыраңқы датчиктер</td>
                                <td>Деректерді бірыңғай модельге біріктірудің жеткіліксіздігі</td>
                                <td class="highlight-cell">Бірыңғай PostgreSQL архитектурасы + Feature Engineering</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </section>

        <!-- 6. Архитектура системы -->
        <section>
            <div class="content-wrapper">
                <h2 class="fade-up">Жүйе архитектурасы</h2>
                <div class="flow-diagram fade-up delay-1">
                    <div class="flow-node"><i class="fa-solid fa-satellite-dish"></i><br>Дереккөздер<br><small>(IoT / Traffic API)</small></div>
                    <div class="flow-arrow"><i class="fa-solid fa-arrow-right"></i></div>
                    <div class="flow-node" style="border-color: #10b981;"><i class="fa-solid fa-server"></i><br>Backend API<br><small>(Django / DRF)</small></div>
                    <div class="flow-arrow"><i class="fa-solid fa-arrow-right"></i></div>
                    <div class="flow-node" style="border-color: #3b82f6;"><i class="fa-solid fa-database"></i><br>PostgreSQL<br><small>(Time-Series DB)</small></div>
                    <div class="flow-arrow"><i class="fa-solid fa-arrow-right"></i></div>
                    <div class="flow-node" style="border-color: #ef4444;"><i class="fa-solid fa-brain"></i><br>ML Модулі<br><small>(Forecasting)</small></div>
                    <div class="flow-arrow"><i class="fa-solid fa-arrow-right"></i></div>
                    <div class="flow-node" style="border-color: #8b5cf6;"><i class="fa-solid fa-desktop"></i><br>Dashboard<br><small>(City Analyst)</small></div>
                </div>
                <div class="glass-card fade-up delay-2" style="margin-top: 30px;">
                    <ul class="custom-list">
                        <li><strong>Backend API</strong> деректерді бағыттауды және бизнес-логиканы қамтамасыз етеді.</li>
                        <li><strong>PostgreSQL</strong> уақыттық қатарлардың (Time-series records) тарихын сенімді сақтайды.</li>
                        <li><strong>ML-модулі</strong> тарихты асинхронды түрде шығарып, жақын арадағы көкжиекке болжам жасайды.</li>
                        <li><strong>Dashboard</strong> соңғы пайдаланушы үшін аналитиканы визуалдайды.</li>
                    </ul>
                </div>
            </div>
        </section>

        <!-- 7. Стек технологий -->
        <section>
            <div class="content-wrapper">
                <h2 class="fade-up">Технологиялық стек</h2>
                <div class="grid-3 fade-up delay-1">
                    <div class="glass-card">
                        <h3><i class="fa-brands fa-python"></i> Backend</h3>
                        <p>Django, Django REST Framework, Gunicorn, Nginx</p>
                    </div>
                    <div class="glass-card">
                        <h3><i class="fa-solid fa-database"></i> Деректер базасы</h3>
                        <p>PostgreSQL, Psycopg2, Time-series optimization</p>
                    </div>
                    <div class="glass-card">
                        <h3><i class="fa-solid fa-network-wired"></i> ML Фреймворктер</h3>
                        <p>PyTorch, scikit-learn, Pandas, NumPy</p>
                    </div>
                    <div class="glass-card">
                        <h3><i class="fa-solid fa-microchip"></i> ML Модельдері</h3>
                        <p>LSTM, Random Forest, Moving Average, Naive, Linear Reg.</p>
                    </div>
                    <div class="glass-card">
                        <h3><i class="fa-brands fa-html5"></i> Frontend / UI</h3>
                        <p>HTML5, CSS3, JavaScript, React, Chart.js / Leaflet</p>
                    </div>
                    <div class="glass-card">
                        <h3><i class="fa-solid fa-table"></i> Деректер</h3>
                        <p>Трафиктің тарихи жазбалары, Time-series traffic records</p>
                    </div>
                </div>
            </div>
        </section>

        <!-- 8. Data Pipeline -->
        <section>
            <div class="content-wrapper">
                <h2 class="fade-up">Data Pipeline және Feature Engineering</h2>
                <div class="flow-diagram fade-up delay-1" style="font-size: 0.9rem;">
                    <div class="flow-node">Raw Data</div> <div class="flow-arrow"><i class="fa-solid fa-angle-right"></i></div>
                    <div class="flow-node">Preprocessing</div> <div class="flow-arrow"><i class="fa-solid fa-angle-right"></i></div>
                    <div class="flow-node">Feature Eng.</div> <div class="flow-arrow"><i class="fa-solid fa-angle-right"></i></div>
                    <div class="flow-node">Train/Test Split</div> <div class="flow-arrow"><i class="fa-solid fa-angle-right"></i></div>
                    <div class="flow-node">Model Training</div> <div class="flow-arrow"><i class="fa-solid fa-angle-right"></i></div>
                    <div class="flow-node">Evaluation</div> <div class="flow-arrow"><i class="fa-solid fa-angle-right"></i></div>
                    <div class="flow-node">Forecast Output</div> <div class="flow-arrow"><i class="fa-solid fa-angle-right"></i></div>
                    <div class="flow-node">Dashboard View</div>
                </div>
                <div class="glass-card fade-up delay-2">
                    <h3>Ажыратылатын негізгі белгілер (Features)</h3>
                    <div class="grid-3">
                        <ul class="custom-list">
                            <li><span class="badge">timestamp</span> Тіркеу уақыты</li>
                            <li><span class="badge">segment_id</span> Жол идентификаторы</li>
                        </ul>
                        <ul class="custom-list">
                            <li><span class="badge">speed</span> Орташа жылдамдық</li>
                            <li><span class="badge">traffic_level</span> Жүктеме деңгейі</li>
                        </ul>
                        <ul class="custom-list">
                            <li><span class="badge">historical_window</span> Деректер терезесі</li>
                            <li><span class="badge">time_features</span> Сағат, апта күні</li>
                        </ul>
                    </div>
                </div>
            </div>
        </section>

        <!-- 9. ML-модуль -->
        <section>
            <div class="content-wrapper">
                <h2 class="fade-up">ML-модулі: Зерттелетін модельдер</h2>
                <p class="fade-up delay-1">Ғылыми зерттеу аясында болжау модельдерінің кешені жүзеге асырылып, сыналды:</p>
                <div class="grid-2 fade-up delay-2" style="margin-top: 20px;">
                    <div class="glass-card">
                        <h3>Базалық модельдер (Baselines)</h3>
                        <ul class="custom-list">
                            <li><strong>Naive Baseline:</strong> Болжам соңғы белгілі мәнге тең.</li>
                            <li><strong>Moving Average:</strong> Тарихи терезе бойынша жылжымалы орташа мән. Тұрақты трендтер үшін тиімді.</li>
                            <li><strong>Linear Regression Trend:</strong> Сызықтық трендті бөліп көрсету.</li>
                        </ul>
                    </div>
                    <div class="glass-card" style="border-left: 4px solid var(--accent-purple);">
                        <h3>Күрделі модельдер (Advanced)</h3>
                        <ul class="custom-list">
                            <li><strong>Random Forest:</strong> Сызықты емес байланыстарды (апта күні + сағат) анықтауға арналған ансамбльдік модель.</li>
                            <li><strong>LSTM (Long Short-Term Memory):</strong> Уақыттық қатарларды және ұзақ мерзімді тәуелділіктерді талдау үшін арнайы жасалған нейрожелілік архитектура.</li>
                        </ul>
                    </div>
                </div>
                <div class="glass-card fade-up delay-3" style="margin-top: 20px; border-color: var(--accent-cyan); background: rgba(2, 132, 199, 0.05);">
                    <p style="margin:0;"><strong>Ғылыми тәсіл:</strong> Мақсат нейрожелілерді соқыр енгізу емес, әділ салыстыру болды. Қысқа көкжиектерде күшті baseline (Moving Average) жиі жақсырақ метрикаларды көрсетеді, ал LSTM-нің әлеуеті деректер көлемі мен болжау көкжиегі артқан кезде ашылады.</p>
                </div>
            </div>
        </section>

        <!-- 10. LSTM architecture -->
        <section>
            <div class="content-wrapper">
                <h2 class="fade-up">LSTM-моделінің архитектурасы</h2>
                <div class="grid-2 fade-up delay-1" style="align-items: center;">
                    <div class="lstm-diagram">
                        <div class="lstm-block"><strong>Input Sequence</strong><br><small>(Уақыттық терезе: t-N ... t)</small></div>
                        <i class="fa-solid fa-arrow-down flow-arrow"></i>
                        <div class="lstm-block" style="background: rgba(37, 99, 235, 0.1);"><strong>LSTM Layers</strong><br><small>(Уақыттық паттерндерді бөліп алу)</small></div>
                        <i class="fa-solid fa-arrow-down flow-arrow"></i>
                        <div class="lstm-block" style="background: rgba(245, 158, 11, 0.1);"><strong>Hidden State</strong><br><small>(Контекстік вектор)</small></div>
                        <i class="fa-solid fa-arrow-down flow-arrow"></i>
                        <div class="lstm-block" style="background: rgba(16, 185, 129, 0.1);"><strong>Dense (Linear) Layer</strong><br><small>(Регрессиялық түрлендіру)</small></div>
                        <i class="fa-solid fa-arrow-down flow-arrow"></i>
                        <div class="lstm-block" style="border-color: var(--accent-cyan);"><strong>Forecast Output</strong><br><small>(t+1 үшін болжам)</small></div>
                    </div>
                    <div>
                        <div class="glass-card">
                            <h3>Таңдауды негіздеу</h3>
                            <ul class="custom-list">
                                <li>LSTM уақыттық тәуелділіктерді есепке алу үшін <strong>ішкі күйін сақтайды</strong>.</li>
                                <li>Модель <strong>тізбектер (time-windows) бойынша</strong> оқи алады.</li>
                                <li><strong>Шектеу:</strong> артық оқытуды (overfitting) болдырмау үшін тазартылған деректердің едәуір көлемін талап етеді.</li>
                                <li><strong>Гиперпараметрлерге сезімтал</strong> (терезе өлшемі, қабаттар саны, learning rate).</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- 11. Метрики оценки -->
        <section>
            <div class="content-wrapper">
                <h2 class="fade-up">Модельдердің сапасын бағалау метрикалары</h2>
                <p class="fade-up delay-1">Регрессиялық болжамдардың дәлдігін бағалау үшін қатаң математикалық метрикалар қолданылды (үздіксіз шамалар үшін кәдімгі Accuracy қолдану дұрыс емес).</p>
                
                <div class="grid-3 fade-up delay-2" style="margin-top: 30px;">
                    <div class="glass-card" style="text-align: center;">
                        <h1 style="margin-bottom: 10px; font-size: 3rem; color: var(--accent-blue);">MAE</h1>
                        <h3>Mean Absolute Error</h3>
                        <p style="font-size: 1rem;">Болжамның орташа абсолюттік қателігін көрсетеді. Сызықты түрде түсіндіріледі.</p>
                    </div>
                    <div class="glass-card" style="text-align: center;">
                        <h1 style="margin-bottom: 10px; font-size: 3rem; color: var(--accent-purple);">RMSE</h1>
                        <h3>Root Mean Squared Error</h3>
                        <p style="font-size: 1rem;">Болжамның үлкен ауытқулары мен аномальды қателеріне көбірек айыппұл салады.</p>
                    </div>
                    <div class="glass-card" style="text-align: center;">
                        <h1 style="margin-bottom: 10px; font-size: 3rem; color: var(--accent-cyan);">Horizon</h1>
                        <h3>Бағалау көкжиектері</h3>
                        <p style="font-size: 1rem;">Салыстыру екі негізгі жоспарлау көкжиегі бойынша жүргізіледі: <strong>30 және 60 минут</strong>.</p>
                    </div>
                </div>
            </div>
        </section>

        <!-- 12. Результаты экспериментов -->
        <section>
            <div class="content-wrapper">
                <h2 class="fade-up">Эксперименттердің нәтижелері</h2>
                <div class="fade-up delay-1">
                    <table class="academic-table" style="margin-bottom: 20px;">
                        <thead>
                            <tr>
                                <th>Модель (Model)</th>
                                <th>Көкжиек (Horizon)</th>
                                <th>MAE</th>
                                <th>RMSE</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr><td>Moving Average</td><td>30 min</td><td class="highlight-cell">1.54</td><td class="highlight-cell">2.95</td></tr>
                            <tr><td>Naive</td><td>30 min</td><td>1.74</td><td>3.82</td></tr>
                            <tr><td>LSTM</td><td>30 min</td><td>3.16</td><td>3.90</td></tr>
                            <tr><td>Trend LR</td><td>30 min</td><td>4.90</td><td>8.72</td></tr>
                            <tr style="border-top: 2px solid var(--card-border);"><td>Moving Average</td><td>60 min</td><td class="highlight-cell">1.65</td><td class="highlight-cell">3.27</td></tr>
                            <tr><td>Naive</td><td>60 min</td><td>1.80</td><td>4.04</td></tr>
                            <tr><td>LSTM</td><td>60 min</td><td>5.59</td><td>5.99</td></tr>
                            <tr><td>Trend LR</td><td>60 min</td><td>8.00+</td><td>8.72</td></tr>
                        </tbody>
                    </table>
                </div>
                <div class="glass-card fade-up delay-2">
                    <h3>Метрикалар бойынша ғылыми тұжырымдар</h3>
                    <ul class="custom-list">
                        <li><strong>Moving Average</strong> қысқа көкжиектерде ең жақсы нәтиже көрсетіп, сенімді baseline болып табылады.</li>
                        <li><strong>LSTM</strong> әзірге baseline-нан қалып тұр, бұл шектеулі датасетте қалыпты жағдай және гиперпараметрлерді fine-tuning жасауды қажет етеді.</li>
                        <li>Жобаның ғылыми құндылығы — анағұрлым күрделі модельдерді енгізуге дайын толық циклді (жинау → сақтау → ML-болжам → визуализация) құруда.</li>
                    </ul>
                </div>
            </div>
        </section>

        <!-- 13. Dashboard / интерфейс -->
        <section>
            <div class="content-wrapper">
                <h2 class="fade-up">Dashboard: Аналитик интерфейсі</h2>
                <div class="grid-2 fade-up delay-1" style="align-items: center;">
                    <div class="dashboard-mockup">
                        <div class="mockup-header">
                            <div class="mockup-dot"></div><div class="mockup-dot"></div><div class="mockup-dot"></div>
                        </div>
                        <div style="padding: 20px; display: grid; grid-template-columns: 2fr 1fr; gap: 15px; height: 350px;">
                            <div style="background: #f8fafc; border-radius: 8px; border: 1px solid #cbd5e1; position: relative;">
                                <!-- Map Mockup -->
                                <div style="position: absolute; top: 10px; left: 10px; background: rgba(255,255,255,0.9); padding: 5px 10px; border-radius: 4px; font-size: 0.8rem; border: 1px solid #cbd5e1;">City Map / Segments</div>
                                <div style="position: absolute; top: 40%; left: 30%; width: 12px; height: 12px; background: #ef4444; border-radius: 50%; box-shadow: 0 0 10px #ef4444;"></div>
                                <div style="position: absolute; top: 60%; left: 50%; width: 12px; height: 12px; background: #22c55e; border-radius: 50%; box-shadow: 0 0 10px #22c55e;"></div>
                                <div style="position: absolute; top: 30%; left: 70%; width: 12px; height: 12px; background: #eab308; border-radius: 50%; box-shadow: 0 0 10px #eab308;"></div>
                            </div>
                            <div style="display: flex; flex-direction: column; gap: 15px;">
                                <div style="background: rgba(37, 99, 235, 0.05); border: 1px solid var(--accent-blue); padding: 15px; border-radius: 8px; flex: 1;">
                                    <div style="font-size: 0.8rem; color: var(--text-muted);">Current Load</div>
                                    <div style="font-size: 1.8rem; font-weight: bold; color: var(--text-main);">78%</div>
                                </div>
                                <div style="background: rgba(124, 58, 237, 0.05); border: 1px solid var(--accent-purple); padding: 15px; border-radius: 8px; flex: 1;">
                                    <div style="font-size: 0.8rem; color: var(--text-muted);">Forecast +30m</div>
                                    <div style="font-size: 1.8rem; font-weight: bold; color: #dc2626;">85%</div>
                                </div>
                                <div style="background: rgba(239, 68, 68, 0.05); border: 1px solid #ef4444; padding: 15px; border-radius: 8px; flex: 1;">
                                    <div style="font-size: 0.8rem; color: #dc2626;"><i class="fa-solid fa-triangle-exclamation"></i> Alerts</div>
                                    <div style="font-size: 0.9rem;">Congestion ahead</div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div>
                        <div class="glass-card">
                            <h3>Dashboard функционалы</h3>
                            <ul class="custom-list">
                                <li>Интерактивті карта (Road segments).</li>
                                <li>Ағымдағы жүктеме (Real-time).</li>
                                <li>30/60 минутқа болжам (ML Inference).</li>
                                <li>Трафиктің өзгеру графиктері.</li>
                                <li>Аналитикалық метрикалардың карточкалары.</li>
                                <li>Автоматты ескертулер жүйесі (Alerts).</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- 14. SWOT-анализ -->
        <section>
            <div class="content-wrapper">
                <h2 class="fade-up">Архитектураның SWOT-талдауы</h2>
                <div class="grid-2 fade-up delay-1" style="gap: 20px;">
                    <div class="glass-card" style="border-top: 4px solid #16a34a;">
                        <h3 style="color: #16a34a;">S: Strengths (Күшті жақтары)</h3>
                        <ul class="custom-list">
                            <li>Толық end-to-end data pipeline.</li>
                            <li>Machine Learning модульдерінің интеграциясы.</li>
                            <li>Заманауи web-dashboard интерфейсі.</li>
                            <li>Кеңейтілетін микросервистік архитектура.</li>
                        </ul>
                    </div>
                    <div class="glass-card" style="border-top: 4px solid #dc2626;">
                        <h3 style="color: #dc2626;">W: Weaknesses (Әлсіз жақтары)</h3>
                        <ul class="custom-list">
                            <li>LSTM күрделі қосымша баптауларды талап етеді.</li>
                            <li>Деректердің шектеулі тарихи кезеңі.</li>
                            <li>Кіріс API деректерінің сапасына жоғары тәуелділік.</li>
                        </ul>
                    </div>
                    <div class="glass-card" style="border-top: 4px solid #2563eb;">
                        <h3 style="color: #2563eb;">O: Opportunities (Мүмкіндіктер)</h3>
                        <ul class="custom-list">
                            <li>City IoT қалалық жүйелерімен интеграция.</li>
                            <li>Real-time traffic control (бағдаршамдар).</li>
                            <li>Қосымша белгілерді енгізу (ауа райы, ЖКО, іс-шаралар).</li>
                            <li>Ensemble models (LSTM + Moving Average).</li>
                        </ul>
                    </div>
                    <div class="glass-card" style="border-top: 4px solid #d97706;">
                        <h3 style="color: #d97706;">T: Threats (Қауіптер)</h3>
                        <ul class="custom-list">
                            <li>Датчиктерден алынған шулы немесе өткізіп алынған деректер.</li>
                            <li>ДБ жүктемесін масштабтаудың қиындықтары.</li>
                            <li>Көлік паттерндерінің болжаусыз өзгеруі.</li>
                        </ul>
                    </div>
                </div>
            </div>
        </section>

        <!-- 15. Практическая значимость -->
        <section>
            <div class="content-wrapper">
                <h2 class="fade-up">Практикалық маңыздылығы</h2>
                <div class="grid-2 fade-up delay-1">
                    <div class="glass-card">
                        <i class="fa-solid fa-users-gear fa-3x mb-3 text-gradient" style="margin-bottom: 15px;"></i>
                        <h3>Қалалық қызметтер үшін</h3>
                        <p>Құрал аналитиктерге мониторинг үшін ыңғайлы ортаны ұсынады. Жүктемелерді ерте анықтау трафикті проактивті түрде реттеуге мүмкіндік береді.</p>
                    </div>
                    <div class="glass-card">
                        <i class="fa-solid fa-lightbulb fa-3x mb-3 text-gradient" style="margin-bottom: 15px;"></i>
                        <h3>ITS үшін негіз</h3>
                        <p>Әзірленген архитектура мегаполистің Интеллектуалды Көлік Жүйесін (ITS) құру үшін сенімді платформа (backend + ML) қызметін атқарады.</p>
                    </div>
                </div>
            </div>
        </section>

        <!-- 16. Ограничения проекта -->
        <section>
            <div class="content-wrapper">
                <h2 class="fade-up">Зерттеу шектеулері</h2>
                <div class="glass-card fade-up delay-1" style="border-left: 5px solid #d97706;">
                    <h3>Академиялық адалдық</h3>
                    <ul class="custom-list">
                        <li><strong>Модельдер тиімділігі:</strong> Барлық модельдер қолда бар деректер жинағында бірдей тиімді емес. Baseline жиі күрделі нейрожеліні жеңеді.</li>
                        <li><strong>Жалпылау қабілеті:</strong> Жиналған тарихи деректердің қысқа көкжиегі LSTM-моделінің ұзақ мерзімді маусымдық паттерндерді табу қабілетін шектейді.</li>
                        <li><strong>Tuning қажеттілігі:</strong> LSTM архитектурасы одан әрі fine-tuning жасауды және тереңірек Feature Engineering талап етеді.</li>
                        <li><strong>Метрикалар:</strong> Регрессия тапсырмалары (жылдамдықты болжау) үшін Accuracy-ді қолдану концептуалды түрде шектеулі, басымдық қатаң MAE/RMSE-ге берілді.</li>
                    </ul>
                </div>
            </div>
        </section>

        <!-- 17. Roadmap -->
        <section>
            <div class="content-wrapper">
                <h2 class="fade-up">Жүйені дамытудың Roadmap-ы</h2>
                <div class="glass-card fade-up delay-1">
                    <div style="display: flex; flex-direction: column; gap: 20px;">
                        <div style="display: flex; align-items: center; gap: 20px;">
                            <div class="badge" style="width: 80px; text-align: center;">Stage 1</div>
                            <p style="margin: 0;">LSTM үшін Feature Engineering жақсарту және терең Hyperparameter tuning жасау.</p>
                        </div>
                        <div style="display: flex; align-items: center; gap: 20px;">
                            <div class="badge" style="width: 80px; text-align: center;">Stage 2</div>
                            <p style="margin: 0;">Ансамбльдер құру (Ensemble): Moving Average + ML Predictors комбинациясы.</p>
                        </div>
                        <div style="display: flex; align-items: center; gap: 20px;">
                            <div class="badge" style="width: 80px; text-align: center;">Stage 3</div>
                            <p style="margin: 0;">Сыртқы факторларды қосу: ауа райы API, ЖКО тізілімі, қалалық іс-шаралар.</p>
                        </div>
                        <div style="display: flex; align-items: center; gap: 20px;">
                            <div class="badge" style="width: 80px; text-align: center; background: rgba(22, 163, 74, 0.1); border-color: #16a34a; color: #16a34a;">Final</div>
                            <p style="margin: 0;">Жүйенің толыққанды Real-time inference және Cloud Deployment.</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- 18. Заключения -->
        <section>
            <div class="content-wrapper">
                <h2 class="fade-up">Қорытынды тұжырымдар</h2>
                <div class="glass-card fade-up delay-1" style="border-color: var(--accent-cyan); background: rgba(2, 132, 199, 0.05);">
                    <ul class="custom-list">
                        <li>AI-қосымшасының толыққанды архитектурасы әзірленді.</li>
                        <li>Болжаудың ML-модулі жүзеге асырылып, интеграцияланды.</li>
                        <li>Модельдерге қатаң математикалық салыстыру жүргізілді.</li>
                        <li>Тәжірибеде baseline-модельдердің жоғары маңыздылығы расталды.</li>
                        <li><strong>Қорытынды:</strong> Жүйе нақты қалалық IoT-пен интеграциялауға және одан әрі масштабтауға дайын.</li>
                    </ul>
                </div>
            </div>
        </section>

        <!-- 19. Финальный слайд (Назарларыңызға рақмет) -->
        <section>
            <div class="content-wrapper">
                <div style="text-align: center; margin-bottom: 50px;" class="fade-up">
                    <h1 style="font-size: 4.5rem; margin-bottom: 10px;" class="text-gradient">Назарларыңызға рақмет!</h1>
                    <p style="font-size: 1.8rem; color: var(--text-main);">Сұрақтарыңыз болса қуана жауап беремін.</p>
                </div>
                
                <div style="display: flex; justify-content: center; align-items: center; gap: 80px;" class="fade-up delay-1">
                    <div class="glass-card" style="text-align: center; padding: 40px; background: rgba(255, 255, 255, 0.9);">
                        <img src="https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=https://alishoksu-coder.github.io/ai_traffics/&color=0f172a&bgcolor=ffffff" alt="App Download" style="border-radius: 16px; margin-bottom: 15px; width: 250px; height: 250px;">
                        <p style="margin: 0; font-weight: bold; font-size: 1.1rem; color: var(--text-muted);">Қосымшаны жүктеу (App Download)</p>
                    </div>
                    
                    <div style="display: flex; flex-direction: column; gap: 30px;">
                        <div style="display: flex; align-items: center; gap: 20px;">
                            <div style="width: 50px; height: 50px; border-radius: 50%; background: #0284c7; display: flex; align-items: center; justify-content: center; color: white; font-size: 1.5rem;">
                                <i class="fa-solid fa-envelope"></i>
                            </div>
                            <span style="font-size: 1.5rem; font-weight: 600; color: var(--text-main);">alishoksu@enu.kz</span>
                        </div>
                        <div style="display: flex; align-items: center; gap: 20px;">
                            <div style="width: 50px; height: 50px; border-radius: 50%; background: #334155; display: flex; align-items: center; justify-content: center; color: white; font-size: 1.5rem;">
                                <i class="fa-brands fa-github"></i>
                            </div>
                            <span style="font-size: 1.5rem; font-weight: 600; color: var(--text-main);">github.com/alishoksu-coder</span>
                        </div>
                        <div style="display: flex; align-items: center; gap: 20px;">
                            <div style="width: 50px; height: 50px; border-radius: 50%; background: #7c3aed; display: flex; align-items: center; justify-content: center; color: white; font-size: 1.5rem;">
                                <i class="fa-solid fa-graduation-cap"></i>
                            </div>
                            <span style="font-size: 1.5rem; font-weight: 600; color: var(--text-main);">ENU, IT Department, 2026</span>
                        </div>
                    </div>
                </div>
            </div>
        </section>

    </main>

    <script>
        const slidesContainer = document.getElementById('slides-container');
        const slides = document.querySelectorAll('section');
        const navDotsContainer = document.getElementById('nav-dots');
        const counter = document.getElementById('slide-counter');
        
        let currentSlide = 0;
        let isAnimating = false;

        slides.forEach((_, idx) => {
            const dot = document.createElement('div');
            dot.classList.add('nav-dot');
            if (idx === 0) dot.classList.add('active');
            dot.addEventListener('click', () => goToSlide(idx));
            navDotsContainer.appendChild(dot);
        });

        const dots = document.querySelectorAll('.nav-dot');

        function updateUI() {
            slidesContainer.style.transform = `translateY(-${currentSlide * 100}vh)`;
            
            dots.forEach((dot, idx) => {
                dot.classList.toggle('active', idx === currentSlide);
            });
            
            counter.innerText = `${currentSlide + 1} / ${slides.length}`;

            const currentSection = slides[currentSlide];
            const animatedElements = currentSection.querySelectorAll('.fade-up');
            animatedElements.forEach(el => {
                el.classList.remove('visible');
                setTimeout(() => el.classList.add('visible'), 50);
            });
        }

        function goToSlide(index) {
            if (isAnimating || index < 0 || index >= slides.length) return;
            isAnimating = true;
            currentSlide = index;
            updateUI();
            setTimeout(() => isAnimating = false, 600);
        }

        document.addEventListener('keydown', (e) => {
            if (['ArrowDown', 'ArrowRight', 'PageDown', ' '].includes(e.key)) {
                e.preventDefault();
                goToSlide(currentSlide + 1);
            }
            if (['ArrowUp', 'ArrowLeft', 'PageUp'].includes(e.key)) {
                e.preventDefault();
                goToSlide(currentSlide - 1);
            }
            if (e.key === 'Home') goToSlide(0);
            if (e.key === 'End') goToSlide(slides.length - 1);
        });

        document.addEventListener('wheel', (e) => {
            if (isAnimating) return;
            if (e.deltaY > 50) goToSlide(currentSlide + 1);
            else if (e.deltaY < -50) goToSlide(currentSlide - 1);
        }, { passive: true });

        setTimeout(() => updateUI(), 100);
    </script>
</body>
</html>
"""

def generate():
    with open('index.html', 'w', encoding='utf-8') as f:
        f.write(html_content)
    print("Presentation created successfully in index.html (Light theme, Kazakh language)")

if __name__ == '__main__':
    generate()
